module.exports = {
  label: 'Expenses', icon: 'dollar', rights: ['MANAGE EXPENSES'], items: [
    { label: 'Advances', rights: ['MANAGE EXPENSES'], route: '/admin/expenses/advances' },
    { label: 'Expenses', rights: ['MANAGE EXPENSES'], route: '/admin/expenses/expenses' },
    { label: 'Trips', rights: ['MANAGE EXPENSES'], route: '/admin/expenses/trips' },
    { label: 'Admin', rights: ['ADMIN EXPENSES'], items: [
      { label: 'Expense Types', rights: ['ADMIN EXPENSES'], route: '/admin/expenses/expense_types' },
      { label: 'Projects', rights: ['ADMIN EXPENSES'], route: '/admin/expenses/projects' },
      { label: 'Vendors', rights: ['ADMIN EXPENSES'], route: '/admin/expenses/vendors' },
      { label: 'Reports', rights: ['ADMIN EXPENSES'], route: '/admin/expenses/reports' }
    ] }
  ]
}
