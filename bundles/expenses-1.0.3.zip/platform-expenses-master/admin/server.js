import { Router } from 'express'
import resources from 'server/middleware/resources'
import Advance from '../models/advance'
import AdvanceQuery from '../queries/advance_query'
import Expense from '../models/expense'
import ExpenseQuery from '../queries/expense_query'
import ExpenseType from '../models/expense_type'
import ExpenseTypeQuery from '../queries/expense_type_query'
import Member from '../models/member'
import MemberQuery from '../queries/member_query'
import Project from '../models/project'
import ProjectQuery from '../queries/project_query'
import Trip from '../models/trip'
import TripQuery from '../queries/trip_query'
import Vendor from '../models/vendor'
import VendorQuery from '../queries/vendor_query'

var router = Router()

router.use(resources({
  name: 'advance',
  model: Advance,
  query: AdvanceQuery,
  filter: (qb, req) => qb.where('user_id', req.user.get('id')),
  include: ['user','project','expense_type']
}))

router.use(resources({
  name: 'project',
  model: Project,
  query: ProjectQuery,
  resources: [
    {
      name: 'member',
      model: Member,
      query: MemberQuery,
      include: ['user.photo']
    }
  ]
}))

router.use(resources({
  name: 'expense',
  model: Expense,
  query: ExpenseQuery,
  filter: (qb, req) => qb.where('user_id', req.user.get('id')),
  include: ['user','project','expense_type']
}))

router.use(resources({
  name: 'expense_type',
  model: ExpenseType,
  query: ExpenseTypeQuery
}))

router.use(resources({
  name: 'trip',
  model: Trip,
  query: TripQuery,
  filter: (qb, req) => qb.where('user_id', req.user.get('id'))
}))

router.use(resources({
  name: 'vendor',
  model: Vendor,
  query: VendorQuery
}))

export default router
