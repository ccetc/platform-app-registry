export const queue = 'email'

export const process = (job, done) => {
  // TODO: send email
  done()
}
